# AI-Vault Certificate Guidelines

## Issuance Format

- Format: PREFIX-SCOPE-YEAR-SERIAL
- Example: NIAS-GLOBAL-2025-0001

## Verification Status
- Verified: Certificate has been confirmed and timestamped
- Revoked: Certificate was invalidated
- Pending: Awaiting issuer validation

## AI Role Declaration
Describe what role AI (e.g., ChatGPT) played in creating or verifying the certificate.

