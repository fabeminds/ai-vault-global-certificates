# AI-Vault Global Certificates

This is the official public ledger for AI-issued certificates recognized by Fabeminds and powered by OpenAI’s ChatGPT.

## Purpose

To provide a transparent, timestamped, and verifiable registry of certifications created with the assistance of AI.

## First Certificate

- **ID**: NIAS-GLOBAL-2025-0001
- **Framework**: NIAS™ by Fabeminds
- **Issued**: July 7, 2025

## Verification

Each certificate in the `certificates/` folder is individually timestamped and recorded in the `ledger.csv`.

